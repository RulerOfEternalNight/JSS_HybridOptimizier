# Based on the paper: J. S. Saravanan and A. Mahadevan, "AI based parameter estimation of ML model using Hybrid of Genetic Algorithm and Simulated Annealing," 2023 14th International Conference on Computing Communication and Networking Technologies (ICCCNT), Delhi, India, 2023, pp. 1-5, doi: 10.1109/ICCCNT56998.2023.10308077. keywords: {Maximum likelihood estimation;Parameter estimation;Computational modeling;Sociology;Simulated annealing;Predictive models;Probabilistic logic;Genetic Algorithm;Simulated Annealing;Optimization;Hybrid Algorithm;Machine Learning},

## For now, this will work only with Random Forest Classifier on any dataset. 

## works are under progress to extend it to work on other models as well